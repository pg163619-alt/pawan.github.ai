# Cozy Cafe Website

A responsive multi-page cafe website starter built with HTML, CSS, and vanilla JavaScript. It can be opened locally without installing a framework.

## Folder structure

```text
cozy-cafe-website/
├── index.html
├── menu.html
├── about.html
├── contact.html
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
```

## Run locally

1. Extract the project folder if it is in a ZIP file.
2. Open `index.html` in a modern browser.
3. Visit Menu, Our Story, and Contact using the navigation.
4. Add menu items to test the demo cart.

Internet access is required for the remote Unsplash photography and Google Fonts. If offline use is needed, download licensed images into `images/` and replace the remote image URLs in the HTML and CSS.

## Customize before publishing

- Replace sample menu items, descriptions, and prices in `menu.html`, `index.html`, and `js/script.js`.
- Replace all bracketed contact information and add the cafe's real address, opening hours, phone number, and email.
- Update `WHATSAPP_NUMBER` in `js/script.js` with the cafe's WhatsApp number, digits only, including the country code.
- Update `businessEmail` in `js/script.js` with the verified cafe email address. The current contact form validates the fields but does not send or store messages until configured.
- Replace the cafe story, promotion, and any placeholder business claims with verified details.
- Use images you have permission to use and optimize them for web delivery.
- Test on mobile and desktop before sharing with customers.

## Cart and order limitations

The cart is a browser-side demo stored in local storage. The WhatsApp feature prepares an order message and opens WhatsApp after the number is configured. It does not process payments, guarantee availability, calculate delivery/tax fees, or automatically submit an order to a cafe system. A real payment or order-management workflow needs a suitable backend or third-party service.

The contact form currently does not send data to a server. For direct message delivery, connect a trusted form service or build a secure backend. Do not collect payment card details on this static website.

## Publish free with GitHub Pages

1. Create or sign in to a GitHub account.
2. Create a new repository and upload the contents of this folder (the HTML files must be at the repository root).
3. Open the repository's **Settings → Pages**.
4. Choose deployment from the `main` branch and the `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish the site and open the URL it provides.

You can also deploy the folder with a static hosting provider such as Netlify. Check the provider's current free-tier terms before publishing.
