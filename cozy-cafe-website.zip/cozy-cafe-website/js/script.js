/* Cozy Cafe demo interactions. Edit business details and sample menu data before launch. */
(() => {
  "use strict";

  const WHATSAPP_NUMBER = ""; // Add the cafe's WhatsApp number with country code, digits only. Example format: 919876543210
  const CART_KEY = "cozyCafeCartV1";
  const menuData = {
    "velvet-cappuccino": { name: "Velvet Cappuccino", price: 160 },
    "classic-latte": { name: "Classic Latte", price: 170 },
    "americano": { name: "Americano", price: 130 },
    "caramel-iced-coffee": { name: "Caramel Iced Coffee", price: 190 },
    "iced-mocha": { name: "Iced Mocha", price: 210 },
    "masala-chai": { name: "Masala Chai", price: 90 },
    "lemon-iced-tea": { name: "Lemon Iced Tea", price: 120 },
    "chocolate-cake": { name: "Chocolate Slice", price: 220 },
    "butter-croissant": { name: "Butter Croissant", price: 140 },
    "grilled-sandwich": { name: "Grilled Veg Sandwich", price: 180 },
    "classic-burger": { name: "Classic Veg Burger", price: 200 },
    "loaded-fries": { name: "Seasoned Fries", price: 130 }
  };

  const formatINR = (value) => new Intl.NumberFormat("en-IN", {
    style: "currency", currency: "INR", maximumFractionDigits: 0
  }).format(value);

  function readCart() {
    try {
      const raw = localStorage.getItem(CART_KEY);
      const parsed = raw ? JSON.parse(raw) : {};
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
      const clean = {};
      Object.entries(parsed).forEach(([id, qty]) => {
        if (menuData[id] && Number.isInteger(qty) && qty > 0 && qty <= 99) clean[id] = qty;
      });
      return clean;
    } catch (error) {
      console.warn("Cart could not be read from browser storage.", error);
      return {};
    }
  }

  let cart = readCart();

  function saveCart() {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch (error) {
      console.warn("Cart could not be saved. Browser storage may be disabled.", error);
    }
    updateCartCount();
    renderCart();
  }

  function updateCartCount() {
    const count = Object.values(cart).reduce((sum, qty) => sum + qty, 0);
    document.querySelectorAll(".cart-count").forEach((el) => { el.textContent = String(count); });
  }

  function addToCart(id) {
    if (!menuData[id]) return;
    cart[id] = Math.min(99, (cart[id] || 0) + 1);
    saveCart();
    const message = document.getElementById("order-message");
    if (message) message.textContent = `${menuData[id].name} added. Your cart has ${Object.values(cart).reduce((a, b) => a + b, 0)} item(s).`;
  }

  function changeQuantity(id, delta) {
    if (!menuData[id]) return;
    const next = (cart[id] || 0) + delta;
    if (next <= 0) delete cart[id];
    else cart[id] = Math.min(99, next);
    saveCart();
  }

  function renderCart() {
    const container = document.getElementById("cart-items");
    const subtotalEl = document.getElementById("cart-subtotal");
    const totalEl = document.getElementById("cart-total");
    if (!container || !subtotalEl || !totalEl) return;

    const ids = Object.keys(cart).filter((id) => menuData[id] && cart[id] > 0);
    if (!ids.length) {
      container.innerHTML = '<p class="cart-empty">Your cart is empty for now.</p>';
    } else {
      container.replaceChildren();
      ids.forEach((id) => {
        const item = menuData[id];
        const line = document.createElement("article");
        line.className = "cart-line";
        const info = document.createElement("div");
        const title = document.createElement("h3");
        title.textContent = item.name;
        const price = document.createElement("p");
        price.textContent = `${formatINR(item.price)} each · ${formatINR(item.price * cart[id])}`;
        info.append(title, price);

        const actions = document.createElement("div");
        actions.className = "cart-line-actions";
        const minus = document.createElement("button");
        minus.className = "qty-button";
        minus.type = "button";
        minus.textContent = "−";
        minus.setAttribute("aria-label", `Remove one ${item.name}`);
        minus.addEventListener("click", () => changeQuantity(id, -1));
        const quantity = document.createElement("span");
        quantity.textContent = String(cart[id]);
        quantity.setAttribute("aria-label", "Quantity");
        const plus = document.createElement("button");
        plus.className = "qty-button";
        plus.type = "button";
        plus.textContent = "+";
        plus.setAttribute("aria-label", `Add one ${item.name}`);
        plus.addEventListener("click", () => changeQuantity(id, 1));
        const remove = document.createElement("button");
        remove.className = "remove-button";
        remove.type = "button";
        remove.textContent = "Remove";
        remove.addEventListener("click", () => { delete cart[id]; saveCart(); });
        actions.append(minus, quantity, plus, remove);
        line.append(info, actions);
        container.append(line);
      });
    }

    const subtotal = ids.reduce((sum, id) => sum + menuData[id].price * cart[id], 0);
    subtotalEl.textContent = formatINR(subtotal);
    totalEl.textContent = formatINR(subtotal);
  }

  document.addEventListener("click", (event) => {
    const addButton = event.target.closest("[data-add]");
    if (addButton) addToCart(addButton.dataset.add);
  });

  // Mobile navigation
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(open));
    });
    nav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
      nav.classList.remove("open");
      navToggle.setAttribute("aria-expanded", "false");
    }));
  }

  // Menu search and category filtering
  const search = document.getElementById("menu-search");
  const filterButtons = Array.from(document.querySelectorAll("[data-filter]"));
  const menuItems = Array.from(document.querySelectorAll(".menu-item"));
  const emptyState = document.getElementById("empty-state");
  let activeFilter = "all";

  function filterMenu() {
    if (!menuItems.length) return;
    const term = (search?.value || "").trim().toLowerCase();
    let visible = 0;
    menuItems.forEach((item) => {
      const matchesCategory = activeFilter === "all" || item.dataset.category === activeFilter;
      const matchesSearch = `${item.dataset.name || ""} ${item.textContent}`.toLowerCase().includes(term);
      const show = matchesCategory && matchesSearch;
      item.hidden = !show;
      if (show) visible += 1;
    });
    if (emptyState) emptyState.hidden = visible > 0;
  }

  if (search) search.addEventListener("input", filterMenu);
  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      activeFilter = button.dataset.filter || "all";
      filterButtons.forEach((candidate) => {
        const active = candidate === button;
        candidate.classList.toggle("active", active);
        candidate.setAttribute("aria-pressed", String(active));
      });
      filterMenu();
    });
  });

  // WhatsApp order summary. It does not process payments or submit orders by itself.
  const orderButton = document.getElementById("whatsapp-order");
  const orderMessage = document.getElementById("order-message");
  if (orderButton) {
    orderButton.addEventListener("click", () => {
      const ids = Object.keys(cart).filter((id) => menuData[id] && cart[id] > 0);
      if (!ids.length) {
        if (orderMessage) orderMessage.textContent = "Please add at least one item before preparing your order.";
        return;
      }
      if (!/^\d{8,15}$/.test(WHATSAPP_NUMBER)) {
        if (orderMessage) orderMessage.textContent = "WhatsApp is not configured yet. Add the cafe's country code and number in js/script.js.";
        return;
      }
      const lines = ids.map((id) => `• ${menuData[id].name} × ${cart[id]} — ${formatINR(menuData[id].price * cart[id])}`);
      const subtotal = ids.reduce((sum, id) => sum + menuData[id].price * cart[id], 0);
      const note = document.getElementById("customer-note")?.value.trim();
      const message = [
        "Hello Cozy Cafe! I'd like to enquire about this order:",
        "",
        ...lines,
        "",
        `Estimated subtotal: ${formatINR(subtotal)}`,
        note ? `Note: ${note}` : "",
        "",
        "Please confirm availability, final price, and pickup/delivery details."
      ].filter(Boolean).join("\n");
      const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank", "noopener,noreferrer");
      if (orderMessage) orderMessage.textContent = "Your order summary was prepared in WhatsApp. The cafe must confirm availability and price.";
    });
  }

  // Contact form: opens the visitor's email app; no message is sent or stored by this static site.
  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;
      const formData = new FormData(contactForm);
      const name = String(formData.get("name") || "").trim();
      const email = String(formData.get("email") || "").trim();
      const subject = String(formData.get("subject") || "").trim();
      const message = String(formData.get("message") || "").trim();
      const status = document.getElementById("form-status");
      const businessEmail = ""; // Add the cafe's verified email address here before launch.
      if (!businessEmail || !businessEmail.includes("@")) {
        if (status) status.textContent = "Demo form validated. Add the cafe's verified email in js/script.js, or connect a form service to receive messages.";
        return;
      }
      const body = `Name: ${name}\nReply email: ${email}\n\n${message}`;
      window.location.href = `mailto:${encodeURIComponent(businessEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      if (status) status.textContent = "Your email app should open with a prepared message.";
    });
  }

  document.querySelectorAll("[data-year]").forEach((el) => { el.textContent = String(new Date().getFullYear()); });
  updateCartCount();
  renderCart();
})();
